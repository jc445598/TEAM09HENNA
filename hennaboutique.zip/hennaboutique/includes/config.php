<?php
$servername = "localhost";
$username = "jcubitgr_ict";
$password = "123zxc";

// Create connection
$conn = new mysqli($servername, $username, $password,'jcubitgr_hennaboutique');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
?>