


<!-- footer -->
	<div class="footer_top_agile_w3ls">
		<div class="container">
			<div class="col-md-3 footer_grid">
				<h3>Quick Links</h3>
				<ul class="footer_grid_list">
					<li><i class="fa fa-angle-right" aria-hidden="true"></i>
						<a href="index.php">Home</a>
					</li>
					<li><i class="fa fa-angle-right" aria-hidden="true"></i>
						<a href="about.php">About</a>
					</li>
					<li><i class="fa fa-angle-right" aria-hidden="true"></i>
						<a href="gallery.php">Gallery</a>
					</li>
					<li><i class="fa fa-angle-right" aria-hidden="true"></i>
						<a href="contact.php">Contact</a>
					</li>
                                        <li><i class="fa fa-angle-right" aria-hidden="true"></i>
						<a href="http://hennaboutique.jcubitgroup.com/admin/login.php">Admin Login</a>
					</li>

				</ul>
			</div>
			<div class="col-md-3 footer_grid">
				<h3>Contact Info</h3>
				<ul class="address">
					<li><i class="fa fa-map-marker" aria-hidden="true"></i>Brisbane</li>
					<li><i class="fa fa-envelope" aria-hidden="true"></i><a href="mailto:info@example.com">hennaboutiquebrisbane@gmail.com</a></li>
					<li><i class="fa fa-phone" aria-hidden="true"></i> +(61) 404 001 043</li>
				</ul>
			</div>
			<div class="col-md-3 footer_grid">
				<h3>Instagram</h3>
				<div class="footer-grid-instagram">
					<a href="https://www.instagram.com/henna_boutique_brisbane/?hl=en"><img src="images/m6.jpg" alt=" " class="img-responsive"></a>
					</div>
					<div class="footer-grid-instagram">
					<a href="#"><img src="images/m19.jpg" alt=" " class="img-responsive"></a>
					</div>
					<div class="clearfix"> </div>				
			</div>
			<div class="col-md-3 footer_grid ">
				     <div class="connect-social">
					<h3>Connect with us</h3>
					<section class="social">
                        <ul>
							<li><a class="icon fb" href="https://www.facebook.com/hennabrisbane/"><i class="fa fa-facebook"></i></a></li>
							<!--<li><a class="icon tw" href="#"><i class="fa fa-twitter"></i></a></li>
							<li><a class="icon pin" href="#"><i class="fa fa-pinterest"></i></a></li>-->
							<li><a class="icon gp" href="https://www.google.com.au/search?rlz=1C1GGRV_enAU783&ei=FJ16WvPAIoGd0wSawa-gDg&q=henna+boutique+brisbane&oq=henna+boutique+brisbane&gs_l=psy-ab.3..0i71k1l4.4858.4858.0.5042.1.1.0.0.0.0.0.0..0.0....0...1.1.64.psy-ab..1.0.0....0.6izz6xK23us&safe=active&ssui=on"><i class="fa fa-google-plus"></i></a></li>
						</ul>
					</section>

				</div>
			</div>
			<div class="clearfix"> </div>

		</div>
	</div>
	<div class="footer_wthree_agile">
		<p>© 2018 Team09. All rights reserved | Design by <a href="index.php">Team09</a></p>
	</div>
	<!-- //footer -->

	<!-- js -->
	<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
	<script>
	jQuery(document).ready(function(){
	var selector = '.nav li a';

jQuery(selector).on('click', function(){
    jQuery(selector).removeClass('active');
    jQuery(this).addClass('active');
});
});
		</script>
					<script src="js/lightbox-plus-jquery.min.js"> </script>
	<script>
		$('ul.dropdown-menu li').hover(function () {
			$(this).find('.dropdown-menu').stop(true, true).delay(200).fadeIn(500);
		}, function () {
			$(this).find('.dropdown-menu').stop(true, true).delay(200).fadeOut(500);
		});
	</script>
	<!-- //bootstrap-modal-pop-up --> 
	<!-- js -->
	<script>
		$('ul.dropdown-menu li').hover(function () {
			$(this).find('.dropdown-menu').stop(true, true).delay(200).fadeIn(500);
		}, function () {
			$(this).find('.dropdown-menu').stop(true, true).delay(200).fadeOut(500);
		});
	</script>
	<!-- bootstrap-modal-pop-up -->
	<script type="text/javascript" src="js/bootstrap.js"></script>
</body>
</html>
