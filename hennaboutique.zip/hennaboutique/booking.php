<?php
include 'header.php';
 if(isset($_REQUEST['book']))
 {

 $username = $_REQUEST['userName'];
 $lastName = $_REQUEST['lastName'];
 $usermail = $_REQUEST['userEmail'];
 $phone = $_REQUEST['userPhone'];
 $book_date = $_REQUEST['bookingdate'];
 $booking_service = $_REQUEST['bookingservice'];
 $message = $_REQUEST['message'];
 $sql = "insert into Bookings(First_Name,Last_Name,Contact_No,Email,Booking_Date,Booking_Service,Message)values('".$username."','".$lastName."','".$usermail."','".$phone."','".$book_date."','".$booking_service."','".$message."')";   
 $inserted = $conn->query($sql);
 if($inserted){
   $posted = true;
 $msg= 'Successfully Booked!!';
 }
 }
?>
		<!-- /inner_content -->
	<div class="banner-bottom">
		<div class="container">
			<div class="inner_sec_info_agileits_w3">
              <h2 class="heading-agileinfo">Booking Service From Here<span>We offer extensive Services.</span></h2>
				<div class="contact-form">
				<?php if( $posted ) {
				if($msg){
				?>
				<span class="msg"><?php  echo $msg; ?></span><?php } }?>
					     <form method="post">
							 <div class="left_form">
					    	<div>
						    	<span><label>First Name</label></span>
						    	<span><input name="userName" type="text" class="textbox" required=""></span>
						    </div>
							<div>
						    	<span><label>Last Name</label></span>
						    	<span><input name="lastName" type="text" class="textbox" required=""></span>
						    </div>
							<div>
						    	<span><label>Booking Date</label></span>
						    	<span><input name="bookingdate" type="date" class="textbox" required=""></span>
						    </div>
							<div>
						    	<span><label>Booking Service</label></span>
						    	<span><input name="bookingservice" type="text" class="textbox" required=""></span>
						    </div>
					    </div>
					    <div class="right_form">
						 <div>
						    	<span><label>E-mail</label></span>
						    	<span><input name="userEmail" type="email" class="textbox" required=""></span>
						    </div>
						    <div>
						     	<span><label>Phone No.</label></span>
						    	<span><input name="userPhone" type="number" class="textbox" required=""></span>
						    </div>
								<div>					    	
									<span><label>Message</label></span>
									<span><textarea name="message" required> </textarea></span>
								</div>
								<div>
									<span><input type="submit" name="book" value="Book Now" class="myButton"></span>
							  </div>
					    </div>
													   
					    <div class="clearfix"></div>
						</form>
						
				  </div>
			</div>
		

		</div>
	</div>
		
<?php
include 'footer.php'?>